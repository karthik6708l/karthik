cleartrip-cucumber-selenium
===========================

Project to demonstrate automation testing of Cleartrip using cucumber and selenium

Steps to run tests
- Go to project root folder
- Execute mvn verify
